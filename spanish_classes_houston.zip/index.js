
import React from "react";

export default function SpanishClassesHouston() {
  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans">
      {/* Header */}
      <header className="p-6 shadow-md">
        <h1 className="text-3xl font-bold text-center">Clases de Español para Ejecutivos - Houston, TX</h1>
      </header>

      {/* Navigation */}
      <nav className="flex justify-center space-x-4 p-4 bg-gray-100">
        <a href="#inicio" className="hover:underline">Inicio</a>
        <a href="#sobre-nosotros" className="hover:underline">Sobre Nosotros</a>
        <a href="#servicios" className="hover:underline">Servicios</a>
        <a href="#testimonios" className="hover:underline">Testimonios</a>
        <a href="#contacto" className="hover:underline">Contacto</a>
      </nav>

      {/* Inicio */}
      <section id="inicio" className="p-8 text-center">
        <h2 className="text-2xl font-semibold mb-4">Domina el Español con Profesionales</h2>
        <p>Clases personalizadas para ejecutivos que buscan mejorar su comunicación en el mundo de los negocios.</p>
      </section>

      {/* Sobre Nosotros */}
      <section id="sobre-nosotros" className="p-8 bg-gray-50">
        <h2 className="text-2xl font-semibold mb-4">Sobre Nosotros</h2>
        <p>Somos un equipo de profesionales dedicados a la enseñanza del español para ejecutivos en Houston, enfocados en resultados rápidos y efectivos.</p>
      </section>

      {/* Servicios */}
      <section id="servicios" className="p-8">
        <h2 className="text-2xl font-semibold mb-4">Nuestros Servicios</h2>
        <ul className="list-disc list-inside">
          <li>Clases privadas personalizadas</li>
          <li>Talleres de comunicación empresarial</li>
          <li>Capacitación intensiva para equipos corporativos</li>
        </ul>
      </section>

      {/* Testimonios */}
      <section id="testimonios" className="p-8 bg-gray-50">
        <h2 className="text-2xl font-semibold mb-4">Lo que Nuestros Clientes Dicen</h2>
        <blockquote className="italic border-l-4 border-gray-400 pl-4">
          "Gracias a sus clases, mi fluidez en español ha mejorado significativamente en tan solo unos meses." - Juan Pérez
        </blockquote>
      </section>

      {/* Contacto */}
      <section id="contacto" className="p-8">
        <h2 className="text-2xl font-semibold mb-4">Contacto</h2>
        <form className="space-y-4 max-w-md mx-auto">
          <input type="text" placeholder="Nombre" className="w-full p-2 border border-gray-300 rounded" />
          <input type="email" placeholder="Correo Electrónico" className="w-full p-2 border border-gray-300 rounded" />
          <textarea placeholder="Mensaje" className="w-full p-2 border border-gray-300 rounded"></textarea>
          <button type="submit" className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">Enviar</button>
        </form>
      </section>

      {/* Footer */}
      <footer className="p-4 bg-gray-100 text-center">
        <p>&copy; {new Date().getFullYear()} Clases de Español para Ejecutivos en Houston. Todos los derechos reservados.</p>
      </footer>
    </div>
  );
}
